<?php
$members=json_decode(file_get_contents("../database/member.json"),true);
$bookings=json_decode(file_get_contents("../database/bookings.json"),true);
$career=json_decode(file_get_contents("../database/career.json"),true);
?>