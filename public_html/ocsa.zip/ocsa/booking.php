<?php
include_once('header.php');
$servicecharge=0;
$book=[];
for ($i=0; $i <count($services); $i++) { 
	if ($services[$i]['id']==$_GET['id']) {
		array_push($book, $services[$i]);
	}
}
if (!isset($_SESSION['auth'])) {
	echo '<script>window.location.href="member-login.php"</script>';
}else if($profile[0]['membership'] ==1 && $profile[0]['month_available'] > 0){
   $servicecharge=0;
   ?>
     <script type="text/javascript">
     	swal({
		  title: "Congratulations !",
		  text: "You win Rs. <?php echo $book[0]['offer']; ?> free Service !",
		  icon: "success",
		  button: "Get It",
		});
     </script>
<?php
}else{
	$servicecharge=$book[0]['offer'];
	echo '<div style="text-align: center;padding: 15px;"><a href="#" class="btn btn-primary" onclick="window.location.reload(true)">Get A Membership</a></div>';
	?>
   <script type="text/javascript">
   	   swal({
		  title: "Prime Membership Subscription",
		  text: "Your are not a OCSA member . Please take membership for unlimited benifits.Read Our Terms and Condition carefully .T&C Apply ",
		  icon: "success",
		  buttons: true,
		  dangerMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
		  	//itemId, amount,name,mobile,description
		    callRazorPayScript('<?php echo $_SESSION["auth"]; ?>', 3600,'<?php echo $profile[0]["name"];?>', '<?php echo $profile[0]["mobile"];?>','Prime Membership','membership');
		  } else {
		    swal("Your Booking is Guest Member .Thank You !");
		  }
		});


		var callRazorPayScript = function(itemId, amount,name,mobile,description,type) {
			  var merchangeName = "OCSA Pvt. Ltd",
			      img = "images/logo1.png",
			      name = name,
			      description = description,
			      amount = amount
			      
			      //rzp_live_OGeCVaU4dUBYAD
			      //rzp_test_stfYN9mYkreg1U
			  loadExternalScript('https://checkout.razorpay.com/v1/checkout.js').then(function() { 
			    var options = {

			      key: 'rzp_test_stfYN9mYkreg1U',
			      protocol: 'https',
			      hostname: 'api.razorpay.com',
			      amount: amount*100,
			      name: merchangeName,
			      description: description,
			      image: img,
			      prefill: {
			        name: name,
			        mobile:mobile

			      },
			      theme: {
			        color: '#ff0000'
			      },
			      handler: function (transaction, response){
			      	var ti=transaction.razorpay_payment_id;
			        // console.log('transaction id: ' + transaction.razorpay_payment_id);
			        // console.log('memberid:'+itemId);
			        // console.log('name:'+name);
			        // console.log('mobile:'+mobile);
			        // console.log('amount:'+amount);
			        $.post('pay.php',{ti,itemId,name,mobile,amount},function(data){
			            window.location.reload(true);
			        });
			        
			      }
			    };

			    window.rzpay = new Razorpay(options);
			         console.log('name:'+name);
					 console.log('name:'+name);
			        console.log('mobile:'+mobile);
			        console.log('amount:'+amount);
			    

			    rzpay.open();
			  });
			}
   </script>
 <?php
}


?>

<div class="container-fluid" style="background:linear-gradient(45deg, white, #bdb7b794),url(images/services-background.jpg);">
	<h2 align="center">Book Service</h2>
	<hr>
	<h3>Service Charge : &#8377; <?php echo $servicecharge; ?></h3>
	<span>Note: Spare Parts Price not includes in service charge ! <a href="#">READ T&C</a></span>
<form action="book_service.php" method="post" >
	<div class="row">
	<div class="input-field col-md-6 col-sm-12">
		  <label>Service Name</label>
          <input name="servicename" type="text" value="<?php echo $book[0]['title']; ?>" readonly class="form-control">
          <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
          <input type="hidden" name="servicecharge" value="<?php echo $servicecharge; ?>">
          <input type="hidden" name="mid" value="<?php echo $profile[0]['id']; ?>">
    </div>
    <div class="input-field col-md-6 col-sm-12">
		  <label for="name"> Name </label>
          <input name="name" type="text" class="form-control" value="<?php echo $profile[0]['name']; ?>">
    </div>
    <div class="input-field col-md-6 col-sm-12">
		  <label for="mobile">Mobile </label>
          <input name="mobile" type="number" class="form-control" value="<?php echo $profile[0]['mobile']; ?>">
    </div>
    <div class="input-field col-md-6 col-sm-12">
		  <label for="email">Email </label>
          <input name="email" type="email" class="form-control" value="<?php echo $profile[0]['email']; ?>">
    </div>
    <div class="input-field col-md-6 col-sm-12">
    	  <label for="address">Full Address</label>
		  <textarea name="address" class="form-control"><?php echo $profile[0]['address'];?></textarea>
          
    </div>
     <div class="input-field col-md-6 col-sm-12">
     	  <label for="city">City</label>
		  <input type="text" name="city" class="form-control" value="<?php echo $profile[0]['city']; ?>">
          
    </div>
     <div class="input-field col-md-6 col-sm-12">
		  <label for="pincode"> Pincode </label>
          <input name="pincode" type="number" class="form-control" minlength="6" maxlength="6" value="<?php echo $profile[0]['pincode']; ?>">
    </div>
    <div class="input-field col-md-6 col-sm-12">
     	  <label for="city">Contact Person (<span>optional</span>)</label>
		  <input type="text" name="contactperson" class="form-control" >
          
    </div>
    <div class="input-field col-md-6 col-sm-12">
     	  <label for="city">Contact Person Mobile (<span>optional</span>)</label>
		  <input type="number" name="contactpersonmobile" class="form-control" >          
    </div>
    <div class="input-field col-md-6 col-sm-12">
     	  <label for="city">Contact Person Email (<span>optional</span>)</label>
		  <input type="email" name="contactpersonemail" class="form-control" >          
    </div>

    <div class="input-field col-md-12 col-sm-12">
     	  <label for="city">Booking For</label>
		  <select class="form-control" name="booking-for" required="required">
		  	<option value="">Select One</option>
		  	<option>Installation</option>
		  	<option>Unistallation</option>
		  	<option>Repairing</option>
		  </select>
          
    </div>
    <div class="input-field col-md-12 col-sm-12 " style="padding: 15px">
    	  <input type="checkbox" name="" required="required"> I accept all terms & condition .<br> <br> 

          <button type="submit" class="btn btn-success text-white" >Book Now</button>
    </div>

</div>
</form>
</div>

<?php



include_once('footer.php');
?>