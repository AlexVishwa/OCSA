<?php
header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400'); 
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	date_default_timezone_set("Asia/Kolkata");

    $data=file_get_contents("database/member.json");
    $arr=json_decode($data,true);
    $arr[]=array('id'=>time(),'name'=>$_POST['name'],'email'=>$_POST['email'],'mobile'=>$_POST['mobile'],'password'=>$_POST['password'],'address'=>$_POST['address'],'city'=>$_POST['city'],'pincode'=>$_POST['pincode'],'appliance'=>$_POST['appliance'],'quantity'=>$_POST['quantity'],'created'=>date('d-M-Y H:s:i A'),'main_wallet'=>0,'wallet'=>0,'paid_amount'=>0,'membership'=>0,'month_available'=>0);
    file_put_contents('database/member.json', json_encode($arr));
    
    
}

?>
