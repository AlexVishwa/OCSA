<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<img src="https://ocsa.in/images/logo1.png" alt="OCSA PRIVATE LIMITED" title="OCSA PRIVATE LIMITED" style="width: 150px">

				<p class="intro">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. </p>
				<h4>OCSA Private Limited</h4>
				<p>Add: Duplex-71 Green Paradise A to Z Colony Modipuram Meerut U.P. 250110</p>
				<p>Contact : 7817005780, 7817005781, 7817005782, 7817005783, 7817005784, </p>
				<p>Email : contact@ocsa.in </p>
			</div>
			<div class="col-md-3">
				<h3 class="quick_links">Quick Links</h3>
				<ul class="footer-menu">
					<li><a href="#"><i class="fa fa-angle-right"></i> Home</a></li>
					<li><a href="#"><i class="fa fa-angle-right"></i> About</a></li>
					<li><a href="#"><i class="fa fa-angle-right"></i> Services</a></li>
					<li><a href="career.php"><i class="fa fa-angle-right"></i> Career</a></li>
					<li><a href="#"><i class="fa fa-angle-right"></i> Privacy & Policy</a></li>
					<li><a href="#"><i class="fa fa-angle-right"></i> Terms & Conditions</a></li>
					<li><a href="#"><i class="fa fa-angle-right"></i> Contact Us</a></li>
					<li><a href="#"><i class="fa fa-angle-right"></i> Login/Register</a></li>
					

				</ul>
			</div>
			<div class="col-md-3">
				<h3 class="quick_links">Social Links</h3>
				<div class="row social_links">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<a href="#"><i class="fa fa-facebook"></i> <span>Facebook</span></a>
					</div>
					<div class="col-md-12 col-sm-12 col-xs-12">
						<a href="#"><i class="fa fa-whatsapp"></i> <span>WhatsApp</span></a>
					</div>
					<div class="col-md-12 col-sm-12 col-xs-12">
						<a href="#"><i class="fa fa-linkedin"></i> <span>Linked In</span></a>
					</div>
					<div class="col-md-12 col-sm-12 col-xs-12">
						<a href="#"><i class="fa fa-instagram"></i> <span>Instagram</span></a>
					</div>
					<div class="col-md-12 col-sm-12 col-xs-12">
						<a href="#"><i class="fa fa-youtube"></i> <span>YouTube</span></a>
					</div>
					
				</div>
			</div>
			<div class="col-md-3">
				<h3 class="quick_links">Payment Method</h3>
				<img src="images/atm.jpg" style="width: 100%;height: 100px;border-radius: 10px;">
				<br>
				<div class="input-group mb-3" style="margin: 40px 0px 0px 0px;">
				    <input type="text" class="form-control downloadapp"  placeholder="Your Mobile">
				    <div class="input-group-append">
				      <span class="input-group-text" style="background: red;color: #fff;font-weight: bold;">Download App</span>
				    </div>
				</div>
				<br>
				<img src="images/playstore.jpg" style="width: 100%;border-radius: 10px;">
			</div>

		</div>
		<p align="center" style="font-size: 18px;color: #ffc107;">
			&copy;Copyright 2019 : All Rights Reserved.<br>
			Design & Developed By : <a href="http://technicalpointsolution.com">TPS</a>
		</p>
	</div>

</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="js/index.js"></script>
<script type="text/javascript">
	// Function to lazy load a script
  // -----------------------------------------------
  var loadExternalScript = function(path) {
    var result = $.Deferred(),
        script = document.createElement("script");
        
    script.async = "async";
    script.type = "text/javascript";
    script.src = path;
    script.onload = script.onreadystatechange = function(_, isAbort) {
      if (!script.readyState || /loaded|complete/.test(script.readyState)) {
        if (isAbort)
          result.reject();
        else
          result.resolve();
      }
    };

    script.onerror = function() {
      result.reject();
    };

    $("head")[0].appendChild(script);

    return result.promise();
  };



  // Use loadScript to load the Razorpay checkout.js
// -----------------------------------------------

</script>
</body>
</html>