<?php
include_once('header.php');
date_default_timezone_set("Asia/Kolkata");
include_once('sendotp.php');
// array('user_id'=>$_SESSION['uid'],'mobile'=>$_POST['mobile'],'alternate_mobile'=>$_POST['alternate_mobile'],
//  'service'=>$_POST['sname'],'book_for'=>$_POST['soption'],'date'=>date('d-m-Y H:i'))

// <img  src="https://cdn3.iconfinder.com/data/icons/flat-actions-icons-9/792/Tick_Mark_Dark-512.png" class="center" alt="" />
//sendOtp($_POST['mobile'],'Welcome OCSA, You Booked '.$_POST['sname'].' for '.$_POST['soption'].'


$booking=file_get_contents("database/bookings.json");
$arr=json_decode($booking,true);

$id=time();
$arr[]=array('id'=>$id,'sid'=>$_POST['id'],'mid'=>$_POST['mid'],'servicename'=>$_POST['servicename'],'servicecharge'=>$_POST['servicecharge'],'membername'=>$_POST['name'],'mobile'=>$_POST['mobile'],'email'=>$_POST['email'],'address'=>$_POST['address'],'pincode'=>$_POST['pincode'],'city'=>$_POST['city'],'bookingfor'=>$_POST['booking-for'],'date'=>date('d-m-Y H:i:s A'),'status'=>0);
file_put_contents("database/bookings.json", json_encode($arr));
sendOtp($_POST['mobile'],'Welcome to OCSA, Your booking '.$_POST['servicename'].'  for '.$_POST['booking-for'].' successfully booked ! service-id : '.$id.' Thank You !  Contact : cotact@ocsa.in');
?>
<div class="container " style="display: flex;justify-content: center;flex-direction: column;align-items: center;">
<h5 style="padding: 15px;color:green;font-weight: bold;">Service Id: <?php echo $id; ?></h5>
<img  src="https://cdn3.iconfinder.com/data/icons/flat-actions-icons-9/792/Tick_Mark_Dark-512.png" class="center" alt="" style="width: 120px;height: 150px;" />
<p><?php echo $_POST['servicename'] .' for '.$_POST['booking-for']; ?></p>
<h6>Successfully Booked !</h6>
<h6>Thank You for using OCSA Services </h8>
</div>

<script>
  setTimeout(function(){
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
        window.location.href='index.php';
    }
},3000);
</script>
<?php
include_once('footer.php');

?>