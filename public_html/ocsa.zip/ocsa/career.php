<?php
include_once('header.php');
?>
<div class="career"></div>
<div class="container" style="background: #dc354517;">
	<!-- <h3 class="services_title">Register Here</h3> -->
	<h3>Employment Application Form</h3>
	<p style="font-size: 15px;color: gray;">Thank you for your interest in working with us. Please check below for available job opportunities that meet your criteria and send your application by filling out the form.</p>
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<div class="form-group">
			  <label for="usr">Name and Surname: <span class="text-danger">*</span></label>
			  <input type="text" class="form-control" id="fname" placeholder="name and Surname ">
			</div>
		</div>
		<div class="col-md-6 col-sm-12 col-xs-12">
			<div class="form-group">
			  <label for="usr">Mobile: <span class="text-danger">*</span></label>
			  <input type="number" class="form-control" name="number" id="number" placeholder="Your Mobile ">
			  <span class="text-danger number-error"></span>
			</div>
		</div>
		<div class="col-md-6 col-sm-12 col-xs-12">
			<div class="form-group">
			  <label for="usr">Email: </label>
			  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email">
			</div>
		</div>
		<div class="col-md-4 col-sm-12 col-xs-12">
			<div class="form-group">
			  <label for="usr">Pincode: <span class="text-danger">*</span></label>
			  <input type="number" class="form-control" name="pincode" id="pincode" placeholder="Your pincode ">
			</div>
			<div class="pincodearea" ></div>
		</div>
		<div class="col-md-4 col-sm-12 col-xs-12">
			<div class="form-group">
			  <label for="usr">Post Office: </label>
			  <input type="text" class="form-control" name="postoffice" id="postoffice" placeholder="Post Office">
			</div>
		</div>
		<div class="col-md-4 col-sm-12 col-xs-12">
			<div class="form-group">
			  <label for="usr">City: </label>
			  <input type="text" class="form-control" name="city" id="city" placeholder="City">
			</div>
		</div>
		<div class="col-md-6 col-sm-12 col-xs-12">
			<div class="form-group">
			  <label for="usr">State: </label>
			  <input type="text" class="form-control" name="state" id="state" placeholder="State">
			</div>
		</div>
		<div class="col-md-6 col-sm-12 col-xs-12">
			<div class="form-group">
			  <label for="usr">Country: </label>
			  <input type="text" class="form-control" name="country" id="country" placeholder="Country">
			</div>
		</div>
		<div class="col-md-12 col-sm-12 col-xs-12">
			<div class="form-group">
			  <label for="usr">Full Address : <span class="text-danger">*</span></label>
			  <textarea class="form-control" name="fulladdress" id="fulladdress" placeholder="Fulladdress"></textarea>
			</div>
		</div>
	</div>
</div>
<!-- otp verified modal start here -->
<div class="emp_otp_modal">
	<div class="content-body">
			<div class="form-group">
			  <label for="usr">Enter OTP Here: </label>
			  <input type="number" class="form-control" name="otp" id="otp" placeholder="OTP">
			</div>

			<div style="display: flex;justify-content: flex-end;">
				<button id="cancle">Cancle</button><button id="submit">Submit</button>
			</div>
	</div>
</div>
<!-- otp verified modal end here -->
<?php
include_once('footer.php');
?>