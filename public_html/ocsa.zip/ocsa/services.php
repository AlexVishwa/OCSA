<!-- services box -->
<div id="services " class="container service">
    <h1 id="services_heading">Our Services</h1>
    <h3 class="services_title">Home Appliances</h3>
    <div id="services-box">
        <?php 
        for($i=0;$i<count($services);$i++){
        ?>
        <a href="booking.php?id=<?php echo $services[$i]['id']; ?>" id="wrapper">
            <div id="img">
                <img src="<?php echo $services[$i]['img']; ?>" alt="">
            </div>
            <div id="title">
              <p>
                <span class="text-success" style="font-size: 20px;font-weight: 900;">&#8377; <?php echo $services[$i]['offer']; ?></span>
                <span class="text-danger" style="text-decoration: line-through;padding: 0px 0px 0px 5px;">&#8377; <?php echo $services[$i]['price']; ?></span>
              </p>
              <span style="color:#0e6aa2;font-weight: bold;font-size: 13px;"><?php echo $services[$i]['title']; ?><span>
                
              </div>
        </a>
        <?php } ?>
    </div>

  </div>
<!-- services box end here -->
<!-- beauty Packages bills -->
<div class="container service beauty_package">
    <h3 class="services_title">Beauty Packages</h3>
    <div class="p-10">
        <h1>Coming Soon</h1>
    </div>
    
</div>
<!-- beauty Packages bills end-->
<!-- recharge and pay bills -->
<div class="container service recharge_bills">
    <h3 class="services_title">Recharge & Pay Bills</h3>
    <div class="p-10">
        <h1>Coming Soon</h1>
    </div>
</div>
<!-- recharge and pay bills end-->
