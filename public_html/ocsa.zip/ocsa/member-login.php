<?php
include_once('header.php');
?>
<div class="container" style="display: flex;flex-direction: column;justify-content: center;align-items: center;padding: 20px 0px;">
	<h2 style="border-bottom: 1px solid;padding-bottom: 5px;">Member Login</h2>

	<form action="member_auth.php" id="member_auth" method="post" style="width: 300px;padding: 30px 5px;">
	  <div class="form-group">
	    <label for="email">Mobile Number:</label>
	    <input type="number" class="form-control" id="mobile" required="required">
	  </div>
	  <div class="form-group">
	    <label for="pwd">Password:</label>
	    <input type="password" class="form-control" id="pwd" required="required">
	  </div>
	  <div class="form-group form-check">
	    <label class="form-check-label">
	      <input class="form-check-input" type="checkbox"> Remember me
	    </label>
	  </div>
	  <button type="submit" class="btn btn-primary" id="mlogin">LOGIN</button>
	</form>
	<p style="font-size: 18px">Don't have an account 
		<a href="member-registration.php" style="background: red;color: yellow;padding: 2px 10px;border-radius: 4px;box-shadow: 1px 1px 10px grey;">Register Now</a></p>
</div>
<?php
include_once('footer.php');
?>