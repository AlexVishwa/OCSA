<?php
include_once('header.php');
include_once('slider.php');
include_once('services.php');
include_once('footer.php');

?>





